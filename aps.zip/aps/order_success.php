<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Successful – APS Mart</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>

    <style>
        /* check animation */
        @keyframes pop {
            0% { transform: scale(0.5); opacity: 0; }
            60% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(1); }
        }

        @keyframes fadeUp {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        .animate-pop {
            animation: pop 0.6s ease-out forwards;
        }

        .animate-fadeUp {
            animation: fadeUp 0.6s ease-out forwards;
        }
    </style>
</head>

<body class="bg-gray-50 min-h-screen flex items-center justify-center px-4">

    <div class="bg-white rounded-2xl shadow-xl p-8 sm:p-10 max-w-md w-full text-center">

        <!-- CHECK ICON -->
        <div class="flex justify-center mb-6">
            <div class="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center animate-pop">
                <svg class="w-12 h-12 text-green-600"
                     fill="none" stroke="currentColor" stroke-width="3"
                     viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M5 13l4 4L19 7" />
                </svg>
            </div>
        </div>

        <!-- TEXT -->
        <h1 class="text-2xl font-bold text-gray-900 mb-2 animate-fadeUp">
            Order Placed Successfully
        </h1>

        <p class="text-gray-600 mb-6 animate-fadeUp" style="animation-delay:0.1s">
            Your payment was successful.  
            We are preparing your order 🚚
        </p>

        <!-- BUTTONS -->
        <div class="flex flex-col gap-3 animate-fadeUp" style="animation-delay:0.2s">

            <a href="profile.php"
               class="bg-green-500 text-white py-3 rounded-lg font-semibold hover:bg-green-600 transition">
                View My Orders
            </a>

            <a href="index.php"
               class="border border-gray-300 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
                Continue Shopping
            </a>

        </div>

    </div>

</body>
</html>
