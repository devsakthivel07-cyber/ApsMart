<?php
session_start();
require_once "config.php";
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
  SELECT 
    c.id AS cart_id,
    c.quantity,
    p.name,
    p.price,
    p.image
  FROM cart c
  JOIN products p ON p.id = c.product_id
  WHERE c.user_id = ?
");
$stmt->execute([$user_id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
        name="description"
        content="APS Mart - Fresh groceries, snacks and stationery delivered in 10 minutes. Order online." />
    <title>APS Mart – Fresh Groceries Delivered</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body class="bg-white">
    <header class="bg-white p-2 shadow-md sticky top-0 z-50">
        <nav class="flex justify-between items-center mx-auto max-w-7xl px-4">
            <a
                href="index.php"
                class="font-semibold text-lg sm:text-xl text-green-500">APS Mart</a>
            <div
                class="hidden md:flex space-x-6 lg:space-x-8 text-decoration-none text-gray-500 font-medium items-center">
                <a
                    href="index.php"
                    class="text-sm lg:text-base hover:text-green-500 transition">Home</a>
                <button
                    onclick="showSearch()"
                    class="text-sm lg:text-base hover:text-green-500 transition">
                    Search
                </button>
                <button
                    onclick="goToProfile()"
                    class="text-sm lg:text-base hover:text-green-500 transition">
                    👤
                </button>
                <button
                    onclick="logout()"
                    id="logoutBtn"
                    class="bg-red-500 text-white px-3 lg:px-4 py-2 rounded-md hover:bg-red-600 transition font-semibold text-sm lg:text-base hidden">
                    Logout
                </button>
                <a href="login.php" id="loginBtn">
                    <button
                        class="bg-green-500 text-white px-3 lg:px-4 py-2 rounded-md hover:bg-green-600 transition font-semibold text-sm lg:text-base">
                        Login
                    </button>
                </a>
            </div>
            <!-- Mobile Menu Button -->
            <button
                id="mobileMenuBtn"
                class="md:hidden text-gray-500 hover:text-green-500">
                <svg
                    class="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24">
                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
            </button>
        </nav>
        <!-- Mobile Menu -->
        <div
            id="mobileMenu"
            class="hidden md:hidden bg-white border-t border-gray-200 px-4 py-4 space-y-3">
            <a
                href="index.php"
                class="block text-gray-500 hover:text-green-500 transition text-sm">Home</a>
            <button
                onclick="showSearch()"
                class="block text-gray-500 hover:text-green-500 transition text-sm">
                Search
            </button>
            <button
                onclick="goToProfile()"
                class="block text-gray-500 hover:text-green-500 transition text-sm">
                Profile
            </button>
            <button
                onclick="logout()"
                id="logoutBtnMobile"
                class="block w-full bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition font-semibold text-sm hidden">
                Logout
            </button>
            <a href="login.php" id="loginBtnMobile" class="block">
                <button
                    class="w-full bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition font-semibold text-sm">
                    Login
                </button>
            </a>
        </div>
    </header>
    <main class="max-w-7xl mx-auto px-4 py-8">

        <h1 class="text-2xl font-bold mb-6">🛒 Shopping Cart</h1>

        <?php if (!$items): ?>
            <div class="bg-white p-8 text-center rounded shadow">
                Cart is empty 😕
            </div>
        <?php else: ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

                <!-- CART ITEMS -->
                <div class="lg:col-span-2 space-y-4">
                    <?php $grandTotal = 0; ?>

                    <?php foreach ($items as $item): ?>
                        <?php
                        $subtotal = $item['price'] * $item['quantity'];
                        $grandTotal += $subtotal;
                        ?>

                        <!-- SINGLE PRODUCT CARD -->
                        <div class="bg-white p-4 rounded shadow flex flex-col sm:flex-row gap-4">

                            <img src="admin/<?= $item['image'] ?>"
                                class="w-24 h-24 object-cover rounded mx-auto sm:mx-0">

                            <div class="flex-1">

                                <div class="flex justify-between items-start">
                                    <h3 class="font-semibold text-lg">
                                        <?= htmlspecialchars($item['name']) ?>
                                    </h3>

                                    <button onclick="removeItem(<?= $item['cart_id'] ?>)"
                                        class="text-red-500 text-sm hover:underline">
                                        ❌
                                    </button>
                                </div>

                                <p class="text-sm text-gray-500 mb-2">
                                    ₹<?= $item['price'] ?> each
                                </p>

                                <!-- QUANTITY -->
                                <div class="flex items-center gap-3">
                                    <button onclick="updateQty(<?= $item['cart_id'] ?>,'dec')"
                                        class="w-8 h-8 bg-gray-200 rounded font-bold">
                                        −
                                    </button>

                                    <span id="qty-<?= $item['cart_id'] ?>" class="font-semibold">
                                        <?= $item['quantity'] ?>
                                    </span>

                                    <button onclick="updateQty(<?= $item['cart_id'] ?>,'inc')"
                                        class="w-8 h-8 bg-gray-200 rounded font-bold">
                                        +
                                    </button>
                                </div>

                                <div id="sub-<?= $item['cart_id'] ?>"
                                    class="mt-3 text-green-600 font-bold text-lg">
                                    ₹<?= $subtotal ?>
                                </div>

                            </div>
                        </div>
                        <!-- END PRODUCT CARD -->

                    <?php endforeach; ?>
                </div>


                <!-- BILLING -->
                <div class="bg-white p-6 rounded shadow h-fit">
                    <h2 class="text-lg font-bold mb-4">🧾 Bill Details</h2>

                    <?php foreach ($items as $item): ?>
                        <div class="flex justify-between items-center text-sm mb-2">
                            <span>
                                <?= htmlspecialchars($item['name']) ?> ×
                                <span id="bill-qty-<?= $item['cart_id'] ?>">
                                    <?= $item['quantity'] ?>
                                </span>
                            </span>

                            <span id="bill-sub-<?= $item['cart_id'] ?>" class="font-medium">
                                ₹<?= $item['price'] * $item['quantity'] ?>
                            </span>
                        </div>
                    <?php endforeach; ?>


                    <hr class="my-3">

                    <div class="flex justify-between font-bold text-lg">
                        <span>Total</span>
                        <span id="grandTotal" class="text-green-600">₹<?= $grandTotal ?></span>
                    </div>

                    <a href="checkout.php"
                        class="block mt-6 bg-green-500 text-white text-center py-3 rounded hover:bg-green-600">
                        Proceed to Checkout
                    </a>
                </div>

            </div>
        <?php endif; ?>

    </main>

    <footer
        class="bg-gray-50 border-t border-gray-200 mt-10 sm:mt-12 md:mt-16 lg:mt-20">
        <div
            class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 sm:py-12 md:py-16">
            <div
                class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 mb-8">
                <!-- Brand Section -->
                <div>
                    <h3 class="text-lg sm:text-xl font-semibold text-green-500 mb-4">
                        APS Mart
                    </h3>
                    <p class="text-gray-600 text-xs sm:text-sm">
                        Your trusted grocery and stationery store
                    </p>
                </div>

                <!-- Quick Links -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Quick Links
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm">
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Home</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Products</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">About Us</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Contact</a>
                        </li>
                    </ul>
                </div>

                <!-- Support -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Support
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm">
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">FAQ</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Shipping Info</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Returns</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Track Order</a>
                        </li>
                    </ul>
                </div>

                <!-- Contact -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Contact Us
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm text-gray-600">
                        <li>Email: info@apsmart.com</li>
                        <li>Phone: +91 9876543210</li>
                        <li>Hours: 9 AM - 9 PM</li>
                        <li>Everyday</li>
                    </ul>
                </div>
            </div>

            <!-- Divider -->
            <div class="border-t border-gray-300 pt-6 sm:pt-8">
                <div class="text-center text-gray-600 text-xs sm:text-sm">
                    <p>&copy; 2026 APS Mart. All rights reserved.</p>
                    <p class="mt-2">
                        Made with <span class="text-green-500">❤</span> for fresh shopping
                    </p>
                </div>
            </div>
        </div>
    </footer>
</body>
<script>
    // Mobile Menu Toggle
    const mobileMenuBtn = document.getElementById("mobileMenuBtn");
    const mobileMenu = document.getElementById("mobileMenu");

    mobileMenuBtn.addEventListener("click", function() {
        mobileMenu.classList.toggle("hidden");
    });

    // Close menu when a link is clicked
    const mobileLinks = mobileMenu.querySelectorAll("a, button");
    mobileLinks.forEach((link) => {
        link.addEventListener("click", function() {
            mobileMenu.classList.add("hidden");
        });
    });

    // Check authentication and update UI
    function updateAuthUI() {
        const isLoggedIn = localStorage.getItem("user_id") !== null;

        document
            .getElementById("loginBtn")
            .classList.toggle("hidden", isLoggedIn);
        document
            .getElementById("loginBtnMobile")
            .classList.toggle("hidden", isLoggedIn);
        document
            .getElementById("logoutBtn")
            .classList.toggle("hidden", !isLoggedIn);
        document
            .getElementById("logoutBtnMobile")
            .classList.toggle("hidden", !isLoggedIn);
    }

    function logout() {
        fetch("logout.php").then(() => {
            localStorage.removeItem("user_id");
            localStorage.removeItem("user_name");
            window.location.href = "login.php";
        });
    }

    function viewCart() {
        if (localStorage.getItem("user_id") === null) {
            window.location.href = "login.php";
            return;
        }
        window.location.href = "cart.php";
    }

    function goToProfile() {
        if (localStorage.getItem("user_id") === null) {
            window.location.href = "login.php";
            return;
        }
        window.location.href = "profile.php";
    }
    function showSearch() {
        // For now, scroll to products section
        document
            .querySelector('[id^="categories"]')
            .scrollIntoView({
                behavior: "smooth"
            });
    }

    function updateQty(cartId, action) {
        fetch("update_cart.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    cart_id: cartId,
                    action: action
                })
            })
            .then(res => res.json())
            .then(data => {
                if (!data.success) return;

                // cart quantity
                document.getElementById("qty-" + cartId).innerText = data.quantity;

                // cart subtotal
                document.getElementById("sub-" + cartId).innerText = "₹" + data.subtotal;

                // billing quantity
                document.getElementById("bill-qty-" + cartId).innerText = data.quantity;

                // billing subtotal
                document.getElementById("bill-sub-" + cartId).innerText = "₹" + data.subtotal;

                recalcTotal();
            });
    }

    function recalcTotal() {
        let total = 0;

        document.querySelectorAll('[id^="bill-sub-"]').forEach(el => {
            total += Number(el.innerText.replace("₹", ""));
        });

        document.getElementById("grandTotal").innerText = "₹" + total;
    }

    function removeItem(cartId) {
        if (!confirm("Remove this item from cart?")) return;

        fetch("remove_cart.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    cart_id: cartId
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
    }
    // Initialize on load
    updateAuthUI();
</script>

</html>