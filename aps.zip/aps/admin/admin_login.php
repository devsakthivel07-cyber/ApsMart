<?php
require_once "../config.php";

// Handle AJAX login request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);

    $email = trim($input['email'] ?? '');
    $password = trim($input['password'] ?? '');

    if ($email === '' || $password === '') {
        echo json_encode([
            "success" => false,
            "message" => "Email and password required"
        ]);
        exit;
    }

    $stmt = $pdo->prepare("SELECT id, name, email, password FROM admins WHERE email = ?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        // Store session
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['name'];

        echo json_encode([
            "success" => true,
            "admin" => [
                "id" => $admin['id'],
                "name" => $admin['name'],
                "email" => $admin['email']
            ]
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Invalid admin credentials"
        ]);
    }
    exit;
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Login - APS Mart</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body class="bg-gray-50">
    <main class="min-h-screen flex items-center justify-center px-4 py-12">
        <div class="w-full max-w-md">
            <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-8">
                <h2 class="text-3xl font-bold text-gray-900 mb-2 text-center">
                    Admin Dashboard
                </h2>
                <p class="text-gray-600 text-center mb-8 text-sm">
                    Authorized access only
                </p>

                <form id="adminLoginForm" class="space-y-5">
                    <div>
                        <label class="block text-gray-800 font-semibold mb-2 text-sm">
                            Admin Email
                        </label>
                        <input type="email" id="email"
                            class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                            required />
                    </div>

                    <div>
                        <label class="block text-gray-800 font-semibold mb-2 text-sm">
                            Password
                        </label>
                        <input type="password" id="password"
                            class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                            required />
                    </div>

                    <button type="submit"
                        class="w-full bg-green-500 text-white py-3 rounded-lg font-semibold hover:bg-green-600">
                        Sign In as Admin
                    </button>
                </form>

                <div class="bg-yellow-50 border border-yellow-200 rounded p-3 mt-6 text-xs">
                    <p><strong>Demo Credentials</strong></p>
                    <p>Email: admin@apsmart.com</p>
                    <p>Password: password</p>
                </div>
            </div>
        </div>
    </main>

    <script>
        document.getElementById("adminLoginForm").addEventListener("submit", function(e) {
            e.preventDefault();

            fetch("", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        email: document.getElementById("email").value,
                        password: document.getElementById("password").value
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert("Login successful");
                        window.location.href = "index.php";
                    } else {
                        alert(data.message);
                    }
                });
        });
    </script>

</body>

</html>