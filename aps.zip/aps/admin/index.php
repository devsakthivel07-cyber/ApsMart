<?php
require_once __DIR__ . '/../config.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ---------------- GLOBAL SETTINGS ---------------- */
error_reporting(E_ALL);
ini_set('display_errors', '1');

/* ---------------- AJAX MODE ---------------- */
if (isset($_GET['action'])) {
    header('Content-Type: application/json');
    try {
        $action = $_GET['action'];

        if ($_GET['action'] === 'stats') {

            $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

            $totalOrders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();

            $pendingOrders = $pdo->query("
        SELECT COUNT(*) FROM orders WHERE status='pending'
    ")->fetchColumn();

            $totalRevenue = $pdo->query("
        SELECT IFNULL(SUM(total),0) FROM orders WHERE status='paid'
    ")->fetchColumn();

            echo json_encode([
                "success" => true,
                "total_users" => (int)$totalUsers,
                "total_orders" => (int)$totalOrders,
                "pending_orders" => (int)$pendingOrders,
                "total_revenue" => (float)$totalRevenue
            ]);
            exit;
        }

        if ($action === 'users') {
            $stmt = $pdo->query("SELECT u.id,u.name,u.email,u.phone,u.created_at,COALESCE(o.cnt,0) AS order_count FROM users u LEFT JOIN (SELECT user_id,COUNT(*) AS cnt FROM orders GROUP BY user_id) o ON u.id=o.user_id ORDER BY u.created_at DESC");
            echo json_encode(['success' => true, 'users' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            exit;
        }

        if ($_GET['action'] === 'orders') {

            $stmt = $pdo->query("
        SELECT 
            o.id,
            o.total,
            o.status,
            o.payment_method,
            o.created_at,
            u.name AS user_name
        FROM orders o
        LEFT JOIN users u ON u.id = o.user_id
        ORDER BY o.created_at DESC
    ");

            echo json_encode([
                "success" => true,
                "orders" => $stmt->fetchAll(PDO::FETCH_ASSOC)
            ]);
            exit;
        }


        if ($action === 'update_order_status') {
            $data = json_decode(file_get_contents('php://input'), true);
            if (!isset($data['order_id'], $data['status'])) {
                echo json_encode(['success' => false, 'message' => 'Invalid payload']);
                exit;
            }
            $stmt = $pdo->prepare('UPDATE orders SET status=? WHERE id=?');
            $stmt->execute([$data['status'], $data['order_id']]);
            echo json_encode(['success' => true]);
            exit;
        }

        if ($action === 'products') {
            $stmt = $pdo->query('SELECT * FROM products ORDER BY created_at DESC');
            echo json_encode(['success' => true, 'products' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            exit;
        }

        if ($action === 'save_product') {
            $id = $_POST['id'] ?? null;
            $imagePath = null;
            if (!empty($_FILES['image']['name'])) {
                $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
                if (!in_array($ext, $allowed)) {
                    echo json_encode(['success' => false, 'message' => 'Invalid image']);
                    exit;
                }
                if (!is_dir(__DIR__ . '/img')) {
                    mkdir(__DIR__ . '/img', 0777, true);
                }
                $file = 'product_' . time() . '.' . $ext;
                $imagePath = 'img/' . $file;
                move_uploaded_file($_FILES['image']['tmp_name'], __DIR__ . '/' . $imagePath);
            }

            if ($id) {
                if ($imagePath) {
                    $stmt = $pdo->prepare('UPDATE products SET name=?,category=?,price=?,quantity=?,description=?,image=? WHERE id=?');
                    $stmt->execute([$_POST['name'], $_POST['category'], $_POST['price'], $_POST['quantity'], $_POST['description'], $imagePath, $id]);
                } else {
                    $stmt = $pdo->prepare('UPDATE products SET name=?,category=?,price=?,quantity=?,description=? WHERE id=?');
                    $stmt->execute([$_POST['name'], $_POST['category'], $_POST['price'], $_POST['quantity'], $_POST['description'], $id]);
                }
            } else {
                $stmt = $pdo->prepare('INSERT INTO products (name,category,price,quantity,description,image) VALUES (?,?,?,?,?,?)');
                $stmt->execute([$_POST['name'], $_POST['category'], $_POST['price'], $_POST['quantity'], $_POST['description'], $imagePath]);
            }
            echo json_encode(['success' => true]);
            exit;
        }

        if ($action === 'delete_product') {
            $data = json_decode(file_get_contents('php://input'), true);
            if (!isset($data['id'])) {
                echo json_encode(['success' => false, 'message' => 'Invalid payload']);
                exit;
            }
            $stmt = $pdo->prepare('SELECT image FROM products WHERE id=?');
            $stmt->execute([$data['id']]);
            $img = $stmt->fetchColumn();
            if ($img && file_exists(__DIR__ . '/' . $img)) {
                unlink(__DIR__ . '/' . $img);
            }
            $pdo->prepare('DELETE FROM products WHERE id=?')->execute([$data['id']]);
            echo json_encode(['success' => true]);
            exit;
        }

        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        exit;
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

/* ---------------- NORMAL PAGE LOAD ---------------- */
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Dashboard - APS Mart</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        /* minimal tweaks if needed */
    </style>
</head>

<body class="bg-gray-100">
    <header class="bg-white shadow-md sticky top-0 z-50">
        <nav class="flex justify-between items-center mx-auto max-w-7xl px-4 py-4">
            <h1 class="font-bold text-2xl text-green-600">APS Mart Admin</h1>
            <div class="flex gap-4 items-center">
                <span id="adminName" class="text-gray-600 text-sm">Admin</span>
                <button id="logoutBtn" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Logout</button>
            </div>
        </nav>
    </header>

    <main class="max-w-7xl mx-auto px-4 py-8">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div class="bg-white rounded-lg shadow p-6">
                <p class="text-gray-600 text-sm mb-2">Total Users</p>
                <p class="text-3xl font-bold text-green-600" id="totalUsers">0</p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <p class="text-gray-600 text-sm mb-2">Total Orders</p>
                <p class="text-3xl font-bold text-blue-600" id="totalOrders">0</p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <p class="text-gray-600 text-sm mb-2">Total Revenue</p>
                <p class="text-3xl font-bold text-purple-600" id="totalRevenue">₹0</p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <p class="text-gray-600 text-sm mb-2">Pending Orders</p>
                <p class="text-3xl font-bold text-yellow-600" id="pendingOrders">0</p>
            </div>
        </div>

        <div class="flex gap-2 mb-6 border-b border-gray-300">
            <button data-tab="users" class="tab-btn active px-4 py-3 border-b-2 border-green-500 font-semibold text-green-600">👥 Users Management</button>
            <button data-tab="orders" class="tab-btn px-4 py-3 border-b-2 border-transparent font-semibold text-gray-600 hover:text-green-600">📦 Orders Management</button>
            <button data-tab="products" class="tab-btn px-4 py-3 border-b-2 border-transparent font-semibold text-gray-600 hover:text-green-600">🛒 Products Management</button>
        </div>

        <div id="users-tab" class="tab-content bg-white rounded-lg shadow p-6">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">Users List</h2>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">ID</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Name</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Email</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Phone</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Joined</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Orders</th>
                        </tr>
                    </thead>
                    <tbody id="usersTable" class="divide-y divide-gray-200">
                        <tr>
                            <td colspan="6" class="px-4 py-8 text-center text-gray-500">Loading users...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="orders-tab" class="tab-content hidden bg-white rounded-lg shadow p-6">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">Orders List</h2>
            <div class="mb-4 flex gap-2">
                <select id="orderStatusFilter" class="px-4 py-2 border border-gray-300 rounded">
                    <option value="">All Status</option>
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="on_the_way">On The Way</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                </select>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Order ID</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">User</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Amount</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Status</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Payment</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Date</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Action</th>
                        </tr>
                    </thead>
                    <tbody id="ordersTable" class="divide-y divide-gray-200">
                        <tr>
                            <td colspan="7" class="px-4 py-8 text-center text-gray-500">Loading orders...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="products-tab" class="tab-content hidden bg-white rounded-lg shadow p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-2xl font-bold text-gray-900">Products List</h2>
                <button id="addProductBtn" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">+ Add Product</button>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">ID</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Name</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Category</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Price</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Stock</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="productsTable" class="divide-y divide-gray-200">
                        <tr>
                            <td colspan="6" class="px-4 py-8 text-center text-gray-500">Loading products...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <div id="productModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4 max-h-96 overflow-y-auto">
            <h3 id="productModalTitle" class="text-xl font-bold text-gray-900 mb-4">Add Product</h3>
            <form id="productForm" class="space-y-3" enctype="multipart/form-data">
                <input type="hidden" id="productId" name="id" />
                <div>
                    <label class="block text-sm font-semibold mb-1">Product Name</label>
                    <input type="text" id="productName" name="name" class="w-full border border-gray-300 rounded px-3 py-2" required />
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-1">Category</label>
                    <select id="productCategory" name="category" class="w-full border border-gray-300 rounded px-3 py-2" required>
                        <option value="Fruits">Fruits</option>
                        <option value="Vegetables">Vegetables</option>
                        <option value="Dairy">Dairy</option>
                        <option value="Bakery">Bakery</option>
                        <option value="Beverages">Beverages</option>
                        <option value="Snacks">Snacks</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-1">Price (₹)</label>
                    <input type="number" id="productPrice" name="price" class="w-full border border-gray-300 rounded px-3 py-2" step="0.01" required />
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-1">Quantity (Stock)</label>
                    <input type="number" id="productQuantity" name="quantity" class="w-full border border-gray-300 rounded px-3 py-2" min="0" value="0" />
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-1">Product Image</label>
                    <input type="file" id="productImage" name="image" class="w-full border border-gray-300 rounded px-3 py-2" accept="image/*" />
                    <p class="text-xs text-gray-500 mt-1" id="productImageHint">JPG, PNG, GIF or WebP (Max 5MB). Optional when editing.</p>
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-1">Description</label>
                    <textarea id="productDesc" name="description" class="w-full border border-gray-300 rounded px-3 py-2 h-20" required></textarea>
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="flex-1 bg-green-500 text-white py-2 rounded hover:bg-green-600">Save</button>
                    <button type="button" id="productCancel" class="flex-1 bg-gray-300 text-gray-900 py-2 rounded hover:bg-gray-400">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let adminProducts = [];

        function switchTab(tab) {
            document.querySelectorAll('.tab-content').forEach(t => t.classList.add('hidden'));
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('border-green-500', 'text-green-600'));
            document.getElementById(tab + '-tab').classList.remove('hidden');
            document.querySelector(`[data-tab="${tab}"]`).classList.add('border-green-500', 'text-green-600');
            if (tab === 'users') loadUsers();
            if (tab === 'orders') loadOrders();
            if (tab === 'products') loadProducts();
        }

        function showAddProduct() {
            document.getElementById('productForm').reset();
            document.getElementById('productId').value = '';
            document.getElementById('productModalTitle').textContent = 'Add Product';
            document.getElementById('productModal').classList.remove('hidden');
        }

        function closeProductModal() {
            document.getElementById('productModal').classList.add('hidden');
        }

        function editProduct(id) {
            const p = adminProducts.find(x => x.id == id);
            if (!p) return alert('Product not found');
            document.getElementById('productId').value = p.id;
            document.getElementById('productName').value = p.name;
            document.getElementById('productCategory').value = p.category;
            document.getElementById('productPrice').value = p.price;
            document.getElementById('productQuantity').value = p.quantity;
            document.getElementById('productDesc').value = p.description;
            document.getElementById('productModalTitle').textContent = 'Edit Product';
            document.getElementById('productModal').classList.remove('hidden');
        }

        async function loadStats() {
            const res = await fetch('?action=stats').then(r => r.json());
            if (!res.success) return;
            document.getElementById('totalUsers').textContent = res.total_users;
            document.getElementById('totalOrders').textContent = res.total_orders;
            document.getElementById('pendingOrders').textContent = res.pending_orders;
            document.getElementById('totalRevenue').textContent = '₹' + res.total_revenue;
        }

        async function loadUsers() {
            const res = await fetch('?action=users').then(r => r.json());
            const tbody = document.getElementById('usersTable');
            if (!res.success) {
                tbody.innerHTML = '<tr><td colspan="6" class="px-4 py-8 text-center text-red-500">Failed to load users</td></tr>';
                return;
            }
            tbody.innerHTML = res.users.map(u => `
                <tr>
                    <td class="px-4 py-3">${u.id}</td>
                    <td class="px-4 py-3">${u.name}</td>
                    <td class="px-4 py-3">${u.email}</td>
                    <td class="px-4 py-3">${u.phone || '-'}</td>
                    <td class="px-4 py-3">${new Date(u.created_at).toLocaleDateString()}</td>
                    <td class="px-4 py-3">${u.order_count}</td>
                </tr>
            `).join('');
        }

        async function loadOrders() {
            const d = await fetch("?action=orders").then(r => r.json());

            if (!d.success) {
                ordersTable.innerHTML = `
            <tr><td colspan="7" class="text-center text-red-500 py-6">
                Failed to load orders
            </td></tr>`;
                return;
            }

            if (d.orders.length === 0) {
                ordersTable.innerHTML = `
            <tr><td colspan="7" class="text-center py-6 text-gray-500">
                No orders found
            </td></tr>`;
                return;
            }

            ordersTable.innerHTML = d.orders.map(o => `
        <tr>
            <td>#${o.id}</td>
            <td>${o.user_name || "Guest"}</td>
            <td>₹${o.total}</td>
            <td>
                <select onchange="updateOrder(${o.id},this.value)"
                        class="border rounded px-2 py-1">
                    ${["pending","paid","delivered","cancelled"]
                        .map(s => `<option value="${s}" ${s===o.status?"selected":""}>${s}</option>`)}
                </select>
            </td>
            <td>${o.payment_method}</td>
            <td>${new Date(o.created_at).toLocaleDateString()}</td>
            <td>-</td>
        </tr>
    `).join("");
        }


        async function updateOrder(id, status) {
            await fetch('?action=update_order_status', {
                method: 'POST',
                body: JSON.stringify({
                    order_id: id,
                    status
                })
            });
            await loadOrders();
        }

        async function loadProducts() {
            const res = await fetch('?action=products').then(r => r.json());
            const tbody = document.getElementById('productsTable');
            if (!res.success) {
                tbody.innerHTML = '<tr><td colspan="6" class="px-4 py-8 text-center text-red-500">Failed to load products</td></tr>';
                return;
            }
            adminProducts = res.products;
            tbody.innerHTML = res.products.map(p => `
                <tr>
                    <td class="px-4 py-3">${p.id}</td>
                    <td class="px-4 py-3">${p.name}</td>
                    <td class="px-4 py-3">${p.category}</td>
                    <td class="px-4 py-3">₹${p.price}</td>
                    <td class="px-4 py-3">${p.quantity}</td>
                    <td class="px-4 py-3">
                        <button onclick="editProduct(${p.id})" class="text-blue-600 mr-2">Edit</button>
                        <button onclick="deleteProduct(${p.id})" class="text-red-600">Delete</button>
                    </td>
                </tr>
            `).join('');
        }

        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.tab-btn').forEach(b => b.addEventListener('click', e => switchTab(b.getAttribute('data-tab'))));
            document.getElementById('addProductBtn').addEventListener('click', showAddProduct);
            document.getElementById('productCancel').addEventListener('click', closeProductModal);
            document.getElementById('logoutBtn').addEventListener('click', () => {
                window.location.href = 'admin_logout.php';
            });

            document.getElementById('productForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                if (!document.getElementById('productId').value && !document.getElementById('productImage').files[0]) {
                    return alert('Please select product image');
                }
                const fd = new FormData(document.getElementById('productForm'));
                await fetch('?action=save_product', {
                    method: 'POST',
                    body: fd
                });
                closeProductModal();
                loadProducts();
            });

            loadStats();
            loadUsers();
        });

        async function deleteProduct(id) {
            if (!confirm('Delete product?')) return;
            await fetch('?action=delete_product', {
                method: 'POST',
                body: JSON.stringify({
                    id
                })
            });
            loadProducts();
        }
    </script>

</body>

<?php ob_end_flush(); ?>

</html>