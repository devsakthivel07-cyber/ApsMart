<?php
session_start();
require_once "config.php";

/* ===== CATEGORY FILTER ===== */
$category = $_GET['category'] ?? 'all';

if ($category === 'all') {
    $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC"); } else {
$stmt = $pdo->prepare("SELECT * FROM products WHERE category=? ORDER BY id
DESC"); $stmt->execute([$category]); } $products =
$stmt->fetchAll(PDO::FETCH_ASSOC); ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
      name="description"
      content="APS Mart - Fresh groceries, snacks and stationery delivered in 10 minutes. Order online."
    />
    <title>APS Mart – Fresh Groceries Delivered</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
  </head>

  <body class="bg-white">
    <header class="bg-white p-2 shadow-md sticky top-0 z-50">
      <nav class="flex justify-between items-center mx-auto max-w-7xl px-4">
        <a
          href="index.php"
          class="font-semibold text-lg sm:text-xl text-green-500"
          >APS Mart</a
        >
        <div
          class="hidden md:flex space-x-6 lg:space-x-8 text-decoration-none text-gray-500 font-medium items-center"
        >
          <a
            href="index.php"
            class="text-sm lg:text-base hover:text-green-500 transition"
            >Home</a
          >
          <button
            onclick="showSearch()"
            class="text-sm lg:text-base hover:text-green-500 transition"
          >
            Search
          </button>
          <button
            onclick="viewCart()"
            class="relative text-sm lg:text-base hover:text-green-500 transition"
          >
            🛒
            <span
              id="cartCount"
              class="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center"
              >0</span
            >
          </button>
          <button
            onclick="goToProfile()"
            class="text-sm lg:text-base hover:text-green-500 transition"
          >
            👤
          </button>
          <button
            onclick="logout()"
            id="logoutBtn"
            class="bg-red-500 text-white px-3 lg:px-4 py-2 rounded-md hover:bg-red-600 transition font-semibold text-sm lg:text-base hidden"
          >
            Logout
          </button>
          <a href="login.html" id="loginBtn">
            <button
              class="bg-green-500 text-white px-3 lg:px-4 py-2 rounded-md hover:bg-green-600 transition font-semibold text-sm lg:text-base"
            >
              Login
            </button>
          </a>
        </div>
        <!-- Mobile Menu Button -->
        <button
          id="mobileMenuBtn"
          class="md:hidden text-gray-500 hover:text-green-500"
        >
          <svg
            class="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M4 6h16M4 12h16M4 18h16"
            ></path>
          </svg>
        </button>
      </nav>
      <!-- Mobile Menu -->
      <div
        id="mobileMenu"
        class="hidden md:hidden bg-white border-t border-gray-200 px-4 py-4 space-y-3"
      >
        <a
          href="index.php"
          class="block text-gray-500 hover:text-green-500 transition text-sm"
          >Home</a
        >
        <button
          onclick="showSearch()"
          class="block text-gray-500 hover:text-green-500 transition text-sm"
        >
          Search
        </button>
        <button
          onclick="viewCart()"
          class="block text-gray-500 hover:text-green-500 transition text-sm"
        >
          Cart
        </button>
        <button
          onclick="goToProfile()"
          class="block text-gray-500 hover:text-green-500 transition text-sm"
        >
          Profile
        </button>
        <button
          onclick="logout()"
          id="logoutBtnMobile"
          class="block w-full bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition font-semibold text-sm hidden"
        >
          Logout
        </button>
        <a href="login.php" id="loginBtnMobile" class="block">
          <button
            class="w-full bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition font-semibold text-sm"
          >
            Login
          </button>
        </a>
      </div>
    </header>
    <!-- PAGE TITLE -->
    <section class="max-w-7xl mx-auto px-4 py-6">
      <h1 class="text-2xl font-bold text-gray-800">
        <?= $category==='all' ? 'All Products' : htmlspecialchars($category) ?>
      </h1>

      <!-- CATEGORY FILTER -->
      <div class="flex gap-2 mt-4 flex-wrap">
        <?php $cats =
        ['all','Fruits','Vegetables','Snacks','Dairy','Bakery','Beverages'];
        foreach ($cats as $c): ?>
        <a
          href="products.php?category=<?= $c ?>"
          class="px-4 py-1 rounded-full border <?= $category===$c ? 'bg-green-500 text-white' : 'bg-white text-gray-600' ?>"
        >
          <?= ucfirst($c) ?>
        </a>
        <?php endforeach; ?>
      </div>
    </section>

    <!-- PRODUCTS GRID -->
    <section class="max-w-7xl mx-auto px-4 pb-12">
      <?php if (count($products) === 0): ?>
      <div class="bg-white p-10 text-center rounded shadow">
        <p class="text-gray-500 text-lg">😕 No products available</p>
      </div>
      <?php else: ?>

      <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        <?php foreach ($products as $p): ?>
        <div
          class="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden"
        >
          <div class="aspect-square bg-gray-100">
            <img
              src="admin/<?= htmlspecialchars($p['image']) ?>"
              class="w-full h-full object-cover"
            />
          </div>

          <div class="p-4">
            <h3 class="font-semibold text-gray-800 truncate">
              <?= htmlspecialchars($p['name']) ?>
            </h3>

            <p class="text-sm text-gray-500 mb-1">
              <?= htmlspecialchars($p['category']) ?>
            </p>

            <p class="text-lg font-bold text-green-600 mb-3">
              ₹<?= $p['price'] ?>
            </p>

            <button
              onclick="addToCart(<?= $p['id'] ?>)"
              class="w-full bg-green-500 text-white py-2 rounded hover:bg-green-600"
            >
              Add to Cart
            </button>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </section>
    <footer
      class="bg-gray-50 border-t border-gray-200 mt-10 sm:mt-12 md:mt-16 lg:mt-20"
    >
      <div
        class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 sm:py-12 md:py-16"
      >
        <div
          class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 mb-8"
        >
          <!-- Brand Section -->
          <div>
            <h3 class="text-lg sm:text-xl font-semibold text-green-500 mb-4">
              APS Mart
            </h3>
            <p class="text-gray-600 text-xs sm:text-sm">
              Your trusted grocery and stationery store
            </p>
          </div>

          <!-- Quick Links -->
          <div>
            <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
              Quick Links
            </h4>
            <ul class="space-y-2 text-xs sm:text-sm">
              <li>
                <a
                  href="#"
                  class="text-gray-600 hover:text-green-500 transition"
                  >Home</a
                >
              </li>
              <li>
                <a
                  href="#"
                  class="text-gray-600 hover:text-green-500 transition"
                  >Products</a
                >
              </li>
              <li>
                <a
                  href="#"
                  class="text-gray-600 hover:text-green-500 transition"
                  >About Us</a
                >
              </li>
              <li>
                <a
                  href="#"
                  class="text-gray-600 hover:text-green-500 transition"
                  >Contact</a
                >
              </li>
            </ul>
          </div>

          <!-- Support -->
          <div>
            <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
              Support
            </h4>
            <ul class="space-y-2 text-xs sm:text-sm">
              <li>
                <a
                  href="#"
                  class="text-gray-600 hover:text-green-500 transition"
                  >FAQ</a
                >
              </li>
              <li>
                <a
                  href="#"
                  class="text-gray-600 hover:text-green-500 transition"
                  >Shipping Info</a
                >
              </li>
              <li>
                <a
                  href="#"
                  class="text-gray-600 hover:text-green-500 transition"
                  >Returns</a
                >
              </li>
              <li>
                <a
                  href="#"
                  class="text-gray-600 hover:text-green-500 transition"
                  >Track Order</a
                >
              </li>
            </ul>
          </div>

          <!-- Contact -->
          <div>
            <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
              Contact Us
            </h4>
            <ul class="space-y-2 text-xs sm:text-sm text-gray-600">
              <li>Email: info@apsmart.com</li>
              <li>Phone: +91 9876543210</li>
              <li>Hours: 9 AM - 9 PM</li>
              <li>Everyday</li>
            </ul>
          </div>
        </div>

        <!-- Divider -->
        <div class="border-t border-gray-300 pt-6 sm:pt-8">
          <div class="text-center text-gray-600 text-xs sm:text-sm">
            <p>&copy; 2026 APS Mart. All rights reserved.</p>
            <p class="mt-2">
              Made with <span class="text-green-500">❤</span> for fresh shopping
            </p>
          </div>
        </div>
      </div>
    </footer>
  </body>
  <script>
    // Mobile Menu Toggle
    const mobileMenuBtn = document.getElementById("mobileMenuBtn");
    const mobileMenu = document.getElementById("mobileMenu");

    mobileMenuBtn.addEventListener("click", function () {
      mobileMenu.classList.toggle("hidden");
    });

    // Close menu when a link is clicked
    const mobileLinks = mobileMenu.querySelectorAll("a, button");
    mobileLinks.forEach((link) => {
      link.addEventListener("click", function () {
        mobileMenu.classList.add("hidden");
      });
    });

    // Check authentication and update UI
    function updateAuthUI() {
      const isLoggedIn = localStorage.getItem("user_id") !== null;

      document
        .getElementById("loginBtn")
        .classList.toggle("hidden", isLoggedIn);
      document
        .getElementById("loginBtnMobile")
        .classList.toggle("hidden", isLoggedIn);
      document
        .getElementById("logoutBtn")
        .classList.toggle("hidden", !isLoggedIn);
      document
        .getElementById("logoutBtnMobile")
        .classList.toggle("hidden", !isLoggedIn);

      updateCartCount();
    }

    async function updateCartCount() {
      try {
        const res = await fetch("cart_count.php");
        const data = await res.json();
        document.getElementById("cartCount").textContent = data.count;
      } catch (e) {
        document.getElementById("cartCount").textContent = "0";
      }
    }

    function logout() {
      fetch("logout.php").then(() => {
        localStorage.removeItem("user_id");
        localStorage.removeItem("user_name");
        window.location.href = "index.php";
      });
    }

    function viewCart() {
      if (localStorage.getItem("user_id") === null) {
        window.location.href = "login.php";
        return;
      }
      window.location.href = "cart.php";
    }

    function goToProfile() {
      if (localStorage.getItem("user_id") === null) {
        window.location.href = "login.php";
        return;
      }
      window.location.href = "profile.php";
    }
    async function addToCart(productId) {
      fetch("add_to_cart.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ product_id: productId }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (!data.success) {
            window.location.href = "login.php";
            return;
          }

          if (data.type === "added") {
            alert("✅ Product added to cart");
          } else if (data.type === "aldready_added") {
            alert("🛒 This Product Is Aldready Added To The Cart");
          }

          updateCartCount();
        });
    }
    function viewCart() {
      if (!localStorage.getItem("user_id")) {
        location.href = "login.php";
        return;
      }
      location.href = "cart.php";
    }

    function goProfile() {
      if (!localStorage.getItem("user_id")) {
        location.href = "login.php";
        return;
      }
      location.href = "profile.php";
    }

    async function addToCart(id) {
      const res = await fetch("add_to_cart.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ product_id: id }),
      });
      const d = await res.json();

      if (d.success) {
        alert("Added to cart");
      } else {
        location.href = "login.php";
      }
    }

    // Initialize on load
    updateAuthUI();
    setInterval(updateCartCount, 5000); // Refresh cart count every 5 seconds
  </script>
</html>
