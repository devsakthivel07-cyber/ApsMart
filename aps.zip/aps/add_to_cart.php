<?php
session_start();
require_once "config.php";

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "login"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$product_id = (int)($data['product_id'] ?? 0);

if ($product_id <= 0) {
    echo json_encode(["success" => false, "message" => "invalid"]);
    exit;
}

$user_id = $_SESSION['user_id'];

// check if already in cart
$stmt = $pdo->prepare("SELECT id, quantity FROM cart WHERE user_id=? AND product_id=?");
$stmt->execute([$user_id, $product_id]);
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if ($item) {
    echo json_encode([
        "success" => true,
        "type" => "aldready_added"
    ]);
} else {
    // new product
    $ins = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?,?,1)");
    $ins->execute([$user_id, $product_id]);

    echo json_encode([
        "success" => true,
        "type" => "added"
    ]);
}
