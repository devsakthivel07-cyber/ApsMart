<?php
session_start();
require_once "config.php";

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success"=>false,"message"=>"Not logged in"]);
    exit;
}

$user_id = $_SESSION['user_id'];

/* ===== GET USER NAME & PHONE ===== */
$userStmt = $pdo->prepare("SELECT name, phone FROM users WHERE id=?");
$userStmt->execute([$user_id]);
$user = $userStmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(["success"=>false,"message"=>"User not found"]);
    exit;
}

$customer_name  = $user['name'];
$customer_phone = $user['phone'];

/* ===== GET ADDRESS ===== */
$addrStmt = $pdo->prepare("SELECT * FROM addresses WHERE user_id=? LIMIT 1");
$addrStmt->execute([$user_id]);
$address = $addrStmt->fetch(PDO::FETCH_ASSOC);

if (!$address) {
    echo json_encode(["success"=>false,"message"=>"Address missing"]);
    exit;
}

$fullAddress = $address['address'] . ", " . $address['city'] . " - " . $address['pincode'];

/* ===== CART TOTAL ===== */
$totalStmt = $pdo->prepare("
    SELECT SUM(p.price * c.quantity)
    FROM cart c
    JOIN products p ON p.id = c.product_id
    WHERE c.user_id=?
");
$totalStmt->execute([$user_id]);
$total = (float)$totalStmt->fetchColumn();

if ($total <= 0) {
    echo json_encode(["success"=>false,"message"=>"Cart empty"]);
    exit;
}

/* ===== CREATE RAZORPAY ORDER (CURL) ===== */
$payload = json_encode([
    "amount" => $total * 100,
    "currency" => "INR"
]);

$ch = curl_init("https://api.razorpay.com/v1/orders");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_USERPWD, RAZORPAY_KEY_ID . ":" . RAZORPAY_SECRET);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

$response = curl_exec($ch);
curl_close($ch);

$order = json_decode($response, true);

if (!isset($order['id'])) {
    echo json_encode(["success"=>false,"message"=>"Razorpay error"]);
    exit;
}

/* ===== SAVE ORDER ===== */
$insert = $pdo->prepare("
    INSERT INTO orders 
    (user_id, total, payment_method, status, customer_name, customer_phone, address)
    VALUES (?,?,?,?,?,?,?)
");

$insert->execute([
    $user_id,
    $total,
    "Razorpay",
    "pending",
    $customer_name,
    $customer_phone,
    $fullAddress
]);

$_SESSION['pending_order_id'] = $pdo->lastInsertId();

/* ===== RESPONSE TO JS ===== */
echo json_encode([
    "success" => true,
    "razorpay_order_id" => $order['id'],
    "amount" => $total * 100
]);
