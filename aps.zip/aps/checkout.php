<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* ADDRESS */
$addrStmt = $pdo->prepare("SELECT * FROM addresses WHERE user_id=? LIMIT 1");
$addrStmt->execute([$user_id]);
$address = $addrStmt->fetch(PDO::FETCH_ASSOC);

/* CART */
$cartStmt = $pdo->prepare("
    SELECT c.quantity, p.name, p.price
    FROM cart c
    JOIN products p ON p.id = c.product_id
    WHERE c.user_id=?
");
$cartStmt->execute([$user_id]);
$items = $cartStmt->fetchAll(PDO::FETCH_ASSOC);

if (!$items) {
    header("Location: cart.php");
    exit;
}

$total = 0;
foreach ($items as $item) {
    $total += $item['price'] * $item['quantity'];
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
        name="description"
        content="APS Mart - Fresh groceries, snacks and stationery delivered in 10 minutes. Order online." />
    <title>APS Mart – Fresh Groceries Delivered</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body class="bg-white">
    <header class="bg-white p-2 shadow-md sticky top-0 z-50">
        <nav class="flex justify-between items-center mx-auto max-w-7xl px-4">
            <a
                href="index.php"
                class="font-semibold text-lg sm:text-xl text-green-500">APS Mart</a>
            <div
                class="hidden md:flex space-x-6 lg:space-x-8 text-decoration-none text-gray-500 font-medium items-center">
                <a
                    href="index.php"
                    class="text-sm lg:text-base hover:text-green-500 transition">Home</a>
                <button
                    onclick="showSearch()"
                    class="text-sm lg:text-base hover:text-green-500 transition">
                    Search
                </button>
                <button
                    onclick="viewCart()"
                    class="relative text-sm lg:text-base hover:text-green-500 transition">
                    🛒
                    <span
                        id="cartCount"
                        class="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">0</span>
                </button>
                <button
                    onclick="logout()"
                    id="logoutBtn"
                    class="bg-red-500 text-white px-3 lg:px-4 py-2 rounded-md hover:bg-red-600 transition font-semibold text-sm lg:text-base hidden">
                    Logout
                </button>
                <a href="login.html" id="loginBtn">
                    <button
                        class="bg-green-500 text-white px-3 lg:px-4 py-2 rounded-md hover:bg-green-600 transition font-semibold text-sm lg:text-base">
                        Login
                    </button>
                </a>
            </div>
            <!-- Mobile Menu Button -->
            <button
                id="mobileMenuBtn"
                class="md:hidden text-gray-500 hover:text-green-500">
                <svg
                    class="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24">
                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
            </button>
        </nav>
        <!-- Mobile Menu -->
        <div
            id="mobileMenu"
            class="hidden md:hidden bg-white border-t border-gray-200 px-4 py-4 space-y-3">
            <a
                href="index.php"
                class="block text-gray-500 hover:text-green-500 transition text-sm">Home</a>
            <button
                onclick="showSearch()"
                class="block text-gray-500 hover:text-green-500 transition text-sm">
                Search
            </button>
            <button
                onclick="viewCart()"
                class="block text-gray-500 hover:text-green-500 transition text-sm">
                Cart
            </button>
            <button
                onclick="logout()"
                id="logoutBtnMobile"
                class="block w-full bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition font-semibold text-sm hidden">
                Logout
            </button>
            <a href="login.php" id="loginBtnMobile" class="block">
                <button
                    class="w-full bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition font-semibold text-sm">
                    Login
                </button>
            </a>
        </div>
    </header>
    <div class="max-w-3xl mx-auto p-6">

        <h1 class="text-2xl font-bold mb-6">Checkout</h1>

        <!-- ADDRESS -->
        <div class="bg-white p-4 rounded shadow mb-6">
            <h2 class="font-bold mb-2">Delivery Address</h2>

            <?php if (!$address): ?>
                <p class="text-red-500">Add address in profile</p>
            <?php else: ?>
                <p><?= nl2br(htmlspecialchars($address['address'])) ?></p>
                <p><?= htmlspecialchars($address['city']) ?> - <?= $address['pincode'] ?></p>

                <!-- IMPORTANT -->
                <input type="hidden" id="address_id" value="<?= $address['id'] ?>">
            <?php endif; ?>
        </div>

        <!-- ORDER SUMMARY -->
        <div class="bg-white p-4 rounded shadow mb-6">
            <h2 class="font-bold mb-3">Order Summary</h2>

            <?php foreach ($items as $item): ?>
                <div class="flex justify-between text-sm mb-1">
                    <span><?= $item['name'] ?> × <?= $item['quantity'] ?></span>
                    <span>₹<?= $item['price'] * $item['quantity'] ?></span>
                </div>
            <?php endforeach; ?>

            <hr class="my-2">

            <div class="flex justify-between font-bold">
                <span>Total</span>
                <span class="text-green-600">₹<?= $total ?></span>
            </div>
        </div>

        <button onclick="payNow()" class="w-full bg-green-500 text-white py-3 rounded">
            Pay Now
        </button>

    </div>

    <footer
        class="bg-gray-50 border-t border-gray-200 mt-10 sm:mt-12 md:mt-16 lg:mt-20">
        <div
            class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 sm:py-12 md:py-16">
            <div
                class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 mb-8">
                <!-- Brand Section -->
                <div>
                    <h3 class="text-lg sm:text-xl font-semibold text-green-500 mb-4">
                        APS Mart
                    </h3>
                    <p class="text-gray-600 text-xs sm:text-sm">
                        Your trusted grocery and stationery store
                    </p>
                </div>

                <!-- Quick Links -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Quick Links
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm">
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Home</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Products</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">About Us</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Contact</a>
                        </li>
                    </ul>
                </div>

                <!-- Support -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Support
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm">
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">FAQ</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Shipping Info</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Returns</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Track Order</a>
                        </li>
                    </ul>
                </div>

                <!-- Contact -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Contact Us
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm text-gray-600">
                        <li>Email: info@apsmart.com</li>
                        <li>Phone: +91 9876543210</li>
                        <li>Hours: 9 AM - 9 PM</li>
                        <li>Everyday</li>
                    </ul>
                </div>
            </div>

            <!-- Divider -->
            <div class="border-t border-gray-300 pt-6 sm:pt-8">
                <div class="text-center text-gray-600 text-xs sm:text-sm">
                    <p>&copy; 2026 APS Mart. All rights reserved.</p>
                    <p class="mt-2">
                        Made with <span class="text-green-500">❤</span> for fresh shopping
                    </p>
                </div>
            </div>
        </div>
    </footer>
</body>

<!-- RAZORPAY SCRIPT -->
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<script>
    // Mobile Menu Toggle
    const mobileMenuBtn = document.getElementById("mobileMenuBtn");
    const mobileMenu = document.getElementById("mobileMenu");

    mobileMenuBtn.addEventListener("click", function() {
        mobileMenu.classList.toggle("hidden");
    });

    // Close menu when a link is clicked
    const mobileLinks = mobileMenu.querySelectorAll("a, button");
    mobileLinks.forEach((link) => {
        link.addEventListener("click", function() {
            mobileMenu.classList.add("hidden");
        });
    });

    // Check authentication and update UI
    function updateAuthUI() {
        const isLoggedIn = localStorage.getItem("user_id") !== null;

        document
            .getElementById("loginBtn")
            .classList.toggle("hidden", isLoggedIn);
        document
            .getElementById("loginBtnMobile")
            .classList.toggle("hidden", isLoggedIn);
        document
            .getElementById("logoutBtn")
            .classList.toggle("hidden", !isLoggedIn);
        document
            .getElementById("logoutBtnMobile")
            .classList.toggle("hidden", !isLoggedIn);

        updateCartCount();
    }

    async function updateCartCount() {
        try {
            const res = await fetch("cart_count.php");
            const data = await res.json();
            document.getElementById("cartCount").textContent = data.count;
        } catch (e) {
            document.getElementById("cartCount").textContent = "0";
        }
    }


    function logout() {
        fetch("logout.php").then(() => {
            localStorage.removeItem("user_id");
            localStorage.removeItem("user_name");
            window.location.href = "index.php";
        });
    }

    function viewCart() {
        if (localStorage.getItem("user_id") === null) {
            window.location.href = "login.php";
            return;
        }
        window.location.href = "cart.php";
    }

    function goToProfile() {
        if (localStorage.getItem("user_id") === null) {
            window.location.href = "login.php";
            return;
        }
        window.location.href = "profile.php";
    }

    function showSearch() {
        // For now, scroll to products section
        document
            .querySelector('[id^="categories"]')
            .scrollIntoView({
                behavior: "smooth"
            });
    }

    // Initialize on load
    updateAuthUI();
</script>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<script>
    async function payNow() {
        const res = await fetch("place_order.php", {
            method: "POST"
        });
        const data = await res.json();

        if (!data.success) {
            alert(data.message);
            return;
        }

        const options = {
            key: "rzp_test_SCjf4eWMRMBYfS",
            amount: data.amount,
            currency: "INR",
            name: "APS Mart",
            order_id: data.razorpay_order_id,
            handler: function(response) {
                fetch("payment_success.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(response)
                }).then(() => {
                    window.location.href = "order_success.php";
                });
            }
        };

        new Razorpay(options).open();
    }
</script>

</html>