<?php
session_start();
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* USER INFO */
$user = $pdo->prepare("SELECT * FROM users WHERE id=?");
$user->execute([$user_id]);
$user = $user->fetch();

/* ADDRESS */
$addr = $pdo->prepare("SELECT * FROM addresses WHERE user_id=?");
$addr->execute([$user_id]);
$address = $addr->fetch();

/* ORDERS */
$orders = $pdo->prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC");
$orders->execute([$user_id]);
$orders = $orders->fetchAll();
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
        name="description"
        content="APS Mart - Fresh groceries, snacks and stationery delivered in 10 minutes. Order online." />
    <title>APS Mart – Fresh Groceries Delivered</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body class="bg-white">
    <header class="bg-white p-2 shadow-md sticky top-0 z-50">
        <nav class="flex justify-between items-center mx-auto max-w-7xl px-4">
            <a
                href="index.php"
                class="font-semibold text-lg sm:text-xl text-green-500">APS Mart</a>
            <div
                class="hidden md:flex space-x-6 lg:space-x-8 text-decoration-none text-gray-500 font-medium items-center">
                <a
                    href="index.php"
                    class="text-sm lg:text-base hover:text-green-500 transition">Home</a>
                <button
                    onclick="showSearch()"
                    class="text-sm lg:text-base hover:text-green-500 transition">
                    Search
                </button>
                <button
                    onclick="viewCart()"
                    class="relative text-sm lg:text-base hover:text-green-500 transition">
                    🛒
                    <span
                        id="cartCount"
                        class="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">0</span>
                </button>
                <button
                    onclick="logout()"
                    id="logoutBtn"
                    class="bg-red-500 text-white px-3 lg:px-4 py-2 rounded-md hover:bg-red-600 transition font-semibold text-sm lg:text-base hidden">
                    Logout
                </button>
                <a href="login.html" id="loginBtn">
                    <button
                        class="bg-green-500 text-white px-3 lg:px-4 py-2 rounded-md hover:bg-green-600 transition font-semibold text-sm lg:text-base">
                        Login
                    </button>
                </a>
            </div>
            <!-- Mobile Menu Button -->
            <button
                id="mobileMenuBtn"
                class="md:hidden text-gray-500 hover:text-green-500">
                <svg
                    class="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24">
                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
            </button>
        </nav>
        <!-- Mobile Menu -->
        <div
            id="mobileMenu"
            class="hidden md:hidden bg-white border-t border-gray-200 px-4 py-4 space-y-3">
            <a
                href="index.php"
                class="block text-gray-500 hover:text-green-500 transition text-sm">Home</a>
            <button
                onclick="showSearch()"
                class="block text-gray-500 hover:text-green-500 transition text-sm">
                Search
            </button>
            <button
                onclick="viewCart()"
                class="block text-gray-500 hover:text-green-500 transition text-sm">
                Cart
            </button>
            <button
                onclick="logout()"
                id="logoutBtnMobile"
                class="block w-full bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition font-semibold text-sm hidden">
                Logout
            </button>
            <a href="login.php" id="loginBtnMobile" class="block">
                <button
                    class="w-full bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition font-semibold text-sm">
                    Login
                </button>
            </a>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <section class="bg-white rounded-lg shadow p-4 space-y-2">
            <button onclick="showTab('profile', this)"
                class="tab-btn flex items-center gap-2 w-full px-4 py-3 rounded-lg font-medium bg-green-50 text-green-600">
                👤 My Profile
            </button>

            <button onclick="showTab('address', this)"
                class="tab-btn flex items-center gap-2 w-full px-4 py-3 rounded-lg font-medium text-gray-600 hover:bg-gray-50">
                📍 My Address
            </button>

            <button onclick="showTab('orders', this)"
                class="tab-btn flex items-center gap-2 w-full px-4 py-3 rounded-lg font-medium text-gray-600 hover:bg-gray-50">
                📦 My Orders
            </button>
        </section>

        <!-- Profile Tab -->
        <section id="profile" class="section bg-white rounded-lg shadow p-6">
            <h2 class="text-xl font-bold mb-4">My Profile</h2>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <p class="text-sm text-gray-500">Name</p>
                    <p class="font-semibold"><?= htmlspecialchars($user['name']) ?></p>
                </div>

                <div>
                    <p class="text-sm text-gray-500">Email</p>
                    <p class="font-semibold"><?= htmlspecialchars($user['email']) ?></p>
                </div>

                <div>
                    <p class="text-sm text-gray-500">Phone</p>
                    <p class="font-semibold"><?= htmlspecialchars($user['phone']) ?></p>
                </div>
            </div>
        </section>


        <!-- Address Tab -->
        <section id="address" class="section hidden bg-white rounded-lg shadow p-6">
            <h2 class="text-xl font-bold mb-4">My Address</h2>

            <form method="POST" action="save_address.php" class="space-y-4">

                <textarea name="address" required
                    class="w-full border rounded-lg p-3"
                    placeholder="Full Address"><?= htmlspecialchars($address['address'] ?? '') ?></textarea>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <input type="text" name="city" required
                        value="<?= htmlspecialchars($address['city'] ?? '') ?>"
                        class="border rounded-lg p-3"
                        placeholder="City">

                    <input type="text" name="pincode" required
                        value="<?= htmlspecialchars($address['pincode'] ?? '') ?>"
                        class="border rounded-lg p-3"
                        placeholder="Pincode">
                </div>

                <button class="bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600">
                    Save Address
                </button>
            </form>
        </section>
        <!-- Orders Tab -->
        <section id="orders" class="section hidden bg-white rounded-lg shadow p-6">
            <h2 class="text-xl font-bold mb-4">My Orders</h2>

            <?php if (!$orders): ?>
                <p class="text-gray-500">No orders yet 😕</p>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($orders as $o): ?>
                        <div class="border rounded-lg p-4">
                            <div class="flex justify-between items-center">
                                <p class="font-semibold">Order #<?= $o['id'] ?></p>
                                <span class="px-3 py-1 text-sm rounded-full
              <?= $o['status'] === 'pending' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700' ?>">
                                    <?= ucfirst($o['status']) ?>
                                </span>
                            </div>

                            <p class="text-sm text-gray-500 mt-1"><?= $o['created_at'] ?></p>
                            <p class="font-bold mt-2">₹<?= $o['total'] ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>


    </main>



    <footer
        class="bg-gray-50 border-t border-gray-200 mt-10 sm:mt-12 md:mt-16 lg:mt-20">
        <div
            class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 sm:py-12 md:py-16">
            <div
                class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 mb-8">
                <!-- Brand Section -->
                <div>
                    <h3 class="text-lg sm:text-xl font-semibold text-green-500 mb-4">
                        APS Mart
                    </h3>
                    <p class="text-gray-600 text-xs sm:text-sm">
                        Your trusted grocery and stationery store
                    </p>
                </div>

                <!-- Quick Links -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Quick Links
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm">
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Home</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Products</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">About Us</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Contact</a>
                        </li>
                    </ul>
                </div>

                <!-- Support -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Support
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm">
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">FAQ</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Shipping Info</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Returns</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Track Order</a>
                        </li>
                    </ul>
                </div>

                <!-- Contact -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Contact Us
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm text-gray-600">
                        <li>Email: info@apsmart.com</li>
                        <li>Phone: +91 9876543210</li>
                        <li>Hours: 9 AM - 9 PM</li>
                        <li>Everyday</li>
                    </ul>
                </div>
            </div>

            <!-- Divider -->
            <div class="border-t border-gray-300 pt-6 sm:pt-8">
                <div class="text-center text-gray-600 text-xs sm:text-sm">
                    <p>&copy; 2026 APS Mart. All rights reserved.</p>
                    <p class="mt-2">
                        Made with <span class="text-green-500">❤</span> for fresh shopping
                    </p>
                </div>
            </div>
        </div>
    </footer>
</body>
<script>
    // Mobile Menu Toggle
    const mobileMenuBtn = document.getElementById("mobileMenuBtn");
    const mobileMenu = document.getElementById("mobileMenu");

    mobileMenuBtn.addEventListener("click", function() {
        mobileMenu.classList.toggle("hidden");
    });

    // Close menu when a link is clicked
    const mobileLinks = mobileMenu.querySelectorAll("a, button");
    mobileLinks.forEach((link) => {
        link.addEventListener("click", function() {
            mobileMenu.classList.add("hidden");
        });
    });

    // Check authentication and update UI
    function updateAuthUI() {
        const isLoggedIn = localStorage.getItem("user_id") !== null;

        document
            .getElementById("loginBtn")
            .classList.toggle("hidden", isLoggedIn);
        document
            .getElementById("loginBtnMobile")
            .classList.toggle("hidden", isLoggedIn);
        document
            .getElementById("logoutBtn")
            .classList.toggle("hidden", !isLoggedIn);
        document
            .getElementById("logoutBtnMobile")
            .classList.toggle("hidden", !isLoggedIn);

        updateCartCount();
    }

    async function updateCartCount() {
        try {
            const res = await fetch("cart_count.php");
            const data = await res.json();
            document.getElementById("cartCount").textContent = data.count;
        } catch (e) {
            document.getElementById("cartCount").textContent = "0";
        }
    }


    function logout() {
        fetch("logout.php").then(() => {
            localStorage.removeItem("user_id");
            localStorage.removeItem("user_name");
            window.location.href = "index.php";
        });
    }

    function viewCart() {
        if (localStorage.getItem("user_id") === null) {
            window.location.href = "login.php";
            return;
        }
        window.location.href = "cart.php";
    }

    function goToProfile() {
        if (localStorage.getItem("user_id") === null) {
            window.location.href = "login.php";
            return;
        }
        window.location.href = "profile.php";
    }

    function showSearch() {
        // For now, scroll to products section
        document
            .querySelector('[id^="categories"]')
            .scrollIntoView({
                behavior: "smooth"
            });
    }

    function showTab(id, btn) {
        document.querySelectorAll(".section").forEach(sec => sec.classList.add("hidden"));
        document.getElementById(id).classList.remove("hidden");

        document.querySelectorAll(".tab-btn").forEach(b => {
            b.classList.remove("bg-green-50", "text-green-600");
            b.classList.add("text-gray-600");
        });

        btn.classList.add("bg-green-50", "text-green-600");
    }

    // Initialize on load
    updateAuthUI();
</script>

</html>