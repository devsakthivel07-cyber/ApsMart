<?php
session_start();
require_once "config.php";

// Fetch products
$stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
$products =
    $stmt->fetchAll(PDO::FETCH_ASSOC); ?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
        name="description"
        content="APS Mart - Fresh groceries, snacks and stationery delivered in 10 minutes. Order online." />
    <title>APS Mart – Fresh Groceries Delivered</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body class="bg-white">
    <header class="bg-white p-2 shadow-md sticky top-0 z-50">
        <nav class="flex justify-between items-center mx-auto max-w-7xl px-4">
            <a
                href="index.php"
                class="font-semibold text-lg sm:text-xl text-green-500">APS Mart</a>
            <div
                class="hidden md:flex space-x-6 lg:space-x-8 text-decoration-none text-gray-500 font-medium items-center">
                <a
                    href="index.php"
                    class="text-sm lg:text-base hover:text-green-500 transition">Home</a>
                <button
                    onclick="showSearch()"
                    class="text-sm lg:text-base hover:text-green-500 transition">
                    Search
                </button>
                <button
                    onclick="viewCart()"
                    class="relative text-sm lg:text-base hover:text-green-500 transition">
                    🛒
                    <span
                        id="cartCount"
                        class="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">0</span>
                </button>
                <button
                    onclick="goToProfile()"
                    class="text-sm lg:text-base hover:text-green-500 transition">
                    👤
                </button>
                <button
                    onclick="logout()"
                    id="logoutBtn"
                    class="bg-red-500 text-white px-3 lg:px-4 py-2 rounded-md hover:bg-red-600 transition font-semibold text-sm lg:text-base hidden">
                    Logout
                </button>
                <a href="login.html" id="loginBtn">
                    <button
                        class="bg-green-500 text-white px-3 lg:px-4 py-2 rounded-md hover:bg-green-600 transition font-semibold text-sm lg:text-base">
                        Login
                    </button>
                </a>
            </div>
            <!-- Mobile Menu Button -->
            <button
                id="mobileMenuBtn"
                class="md:hidden text-gray-500 hover:text-green-500">
                <svg
                    class="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24">
                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
            </button>
        </nav>
        <!-- Mobile Menu -->
        <div
            id="mobileMenu"
            class="hidden md:hidden bg-white border-t border-gray-200 px-4 py-4 space-y-3">
            <a
                href="index.php"
                class="block text-gray-500 hover:text-green-500 transition text-sm">Home</a>
            <button
                onclick="showSearch()"
                class="block text-gray-500 hover:text-green-500 transition text-sm">
                Search
            </button>
            <button
                onclick="viewCart()"
                class="block text-gray-500 hover:text-green-500 transition text-sm">
                Cart
            </button>
            <button
                onclick="goToProfile()"
                class="block text-gray-500 hover:text-green-500 transition text-sm">
                Profile
            </button>
            <button
                onclick="logout()"
                id="logoutBtnMobile"
                class="block w-full bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition font-semibold text-sm hidden">
                Logout
            </button>
            <a href="login.php" id="loginBtnMobile" class="block">
                <button
                    class="w-full bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition font-semibold text-sm">
                    Login
                </button>
            </a>
        </div>
    </header>
    <main class="flex-1">
        <!-- Hero Section -->
        <section class="bg-green-50 py-12 sm:py-16 md:py-20 lg:py-28">
            <div class="mx-auto px-4 sm:px-6 lg:px-8 text-center max-w-5xl">
                <h1
                    class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-3 sm:mb-4 leading-tight">
                    Fresh Groceries,<br /><span class="text-green-500">Delivered to You</span>
                </h1>
                <p
                    class="text-gray-600 text-base sm:text-lg md:text-xl max-w-2xl mx-auto mb-6 sm:mb-8 px-2">
                    Shop from a wide variety of fresh products, snacks, and stationery.
                    Quality items at affordable prices.
                </p>
                <button
                    type="button"
                    class="bg-green-500 text-white px-4 sm:px-6 py-2 sm:py-3 rounded-md hover:bg-green-600 active:scale-95 transition font-semibold text-sm sm:text-base md:text-lg"
                    onclick="
              document
                .getElementById('category-sec')
                .scrollIntoView({ behavior: 'smooth' })
            ">
                    Shop Now
                </button>
            </div>
        </section>
        <!-- Categories Section -->
        <section
            class="py-10 sm:py-12 md:py-16 px-4 sm:px-6 lg:px-8"
            id="category-sec">
            <div class="mx-auto max-w-7xl">
                <h2
                    class="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-center mb-8 sm:mb-10 md:mb-12">
                    Shop by Category
                </h2>
                <div
                    class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-5 lg:gap-6">
                    <a href="product.html?category=Groceries" class="group">
                        <div
                            class="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 cursor-pointer">
                            <div class="aspect-[4/3] overflow-hidden">
                                <img
                                    src="admin/img/groceries.jpeg"
                                    alt="Groceries"
                                    class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            </div>
                            <div class="p-4">
                                <h3 class="text-lg font-semibold text-center text-gray-800">
                                    Groceries
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="product.html?category=Fruits" class="group">
                        <div
                            class="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 cursor-pointer">
                            <div class="aspect-[4/3] overflow-hidden">
                                <img
                                    src="admin/img/fruits.jpeg"
                                    alt="Fruits"
                                    class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            </div>
                            <div class="p-4">
                                <h3 class="text-lg font-semibold text-center text-gray-800">
                                    Fruits
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="product.html?category=Stationery" class="group">
                        <div
                            class="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 cursor-pointer">
                            <div class="aspect-[4/3] overflow-hidden">
                                <img
                                    src="admin/img/stationery.jpeg"
                                    alt="Stationery"
                                    class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            </div>
                            <div class="p-4">
                                <h3 class="text-lg font-semibold text-center text-gray-800">
                                    Stationery
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="product.html?category=Snacks" class="group">
                        <div
                            class="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 cursor-pointer">
                            <div class="aspect-[4/3] overflow-hidden">
                                <img
                                    src="admin/img/snacks.jpeg"
                                    alt="Snacks"
                                    class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            </div>
                            <div class="p-4">
                                <h3 class="text-lg font-semibold text-center text-gray-800">
                                    Snacks
                                </h3>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </section>
        <!-- FEATURED PRODUCTS (DYNAMIC) -->
        <section class="py-12 bg-gray-50">
            <div class="max-w-7xl mx-auto px-4">
                <h2 class="text-3xl font-bold text-center mb-8">Products</h2>

                <?php if (count($products) === 0): ?>
                    <p class="text-center col-span-4 text-gray-500">
                        No products available
                    </p>
                <?php else: ?>
                    <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        <?php foreach ($products as $p): ?>
                            <div class="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-xl transition">

                                <div class="aspect-square overflow-hidden bg-gray-100">
                                    <img
                                        src="admin/<?= htmlspecialchars($p['image']) ?>"
                                        alt="<?= htmlspecialchars($p['name']) ?>"
                                        class="w-full h-full object-cover" />
                                </div>
                                <div class="p-4">
                                    <h3 class="font-medium text-gray-800 mb-1">
                                        <?= htmlspecialchars($p['name']) ?>
                                    </h3>
                                    <p class="text-lg font-bold text-green-500 mb-3">
                                        ₹<?= $p['price'] ?>
                                    </p>
                                    <button
                                        onclick="addToCart(<?= $p['id'] ?>)"
                                        class="w-full bg-green-500 text-white px-3 py-2 rounded-md hover:bg-green-600 transition text-sm">
                                        Add to Cart
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </div>

            </div>
            </div>
        </section>
    </main>
    <footer
        class="bg-gray-50 border-t border-gray-200 mt-10 sm:mt-12 md:mt-16 lg:mt-20">
        <div
            class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 sm:py-12 md:py-16">
            <div
                class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 mb-8">
                <!-- Brand Section -->
                <div>
                    <h3 class="text-lg sm:text-xl font-semibold text-green-500 mb-4">
                        APS Mart
                    </h3>
                    <p class="text-gray-600 text-xs sm:text-sm">
                        Your trusted grocery and stationery store
                    </p>
                </div>

                <!-- Quick Links -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Quick Links
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm">
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Home</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Products</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">About Us</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Contact</a>
                        </li>
                    </ul>
                </div>

                <!-- Support -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Support
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm">
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">FAQ</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Shipping Info</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Returns</a>
                        </li>
                        <li>
                            <a
                                href="#"
                                class="text-gray-600 hover:text-green-500 transition">Track Order</a>
                        </li>
                    </ul>
                </div>

                <!-- Contact -->
                <div>
                    <h4 class="font-semibold text-gray-800 mb-4 text-sm sm:text-base">
                        Contact Us
                    </h4>
                    <ul class="space-y-2 text-xs sm:text-sm text-gray-600">
                        <li>Email: info@apsmart.com</li>
                        <li>Phone: +91 9876543210</li>
                        <li>Hours: 9 AM - 9 PM</li>
                        <li>Everyday</li>
                    </ul>
                </div>
            </div>

            <!-- Divider -->
            <div class="border-t border-gray-300 pt-6 sm:pt-8">
                <div class="text-center text-gray-600 text-xs sm:text-sm">
                    <p>&copy; 2026 APS Mart. All rights reserved.</p>
                    <p class="mt-2">
                        Made with <span class="text-green-500">❤</span> for fresh shopping
                    </p>
                </div>
            </div>
        </div>
    </footer>
</body>
<script>
    // Mobile Menu Toggle
    const mobileMenuBtn = document.getElementById("mobileMenuBtn");
    const mobileMenu = document.getElementById("mobileMenu");

    mobileMenuBtn.addEventListener("click", function() {
        mobileMenu.classList.toggle("hidden");
    });

    // Close menu when a link is clicked
    const mobileLinks = mobileMenu.querySelectorAll("a, button");
    mobileLinks.forEach((link) => {
        link.addEventListener("click", function() {
            mobileMenu.classList.add("hidden");
        });
    });

    // Check authentication and update UI
    function updateAuthUI() {
        const isLoggedIn = localStorage.getItem("user_id") !== null;

        document
            .getElementById("loginBtn")
            .classList.toggle("hidden", isLoggedIn);
        document
            .getElementById("loginBtnMobile")
            .classList.toggle("hidden", isLoggedIn);
        document
            .getElementById("logoutBtn")
            .classList.toggle("hidden", !isLoggedIn);
        document
            .getElementById("logoutBtnMobile")
            .classList.toggle("hidden", !isLoggedIn);

        updateCartCount();
    }

    async function updateCartCount() {
        try {
            const res = await fetch("cart_count.php");
            const data = await res.json();
            document.getElementById("cartCount").textContent = data.count;
        } catch (e) {
            document.getElementById("cartCount").textContent = "0";
        }
    }


    function logout() {
        fetch("logout.php").then(() => {
            localStorage.removeItem("user_id");
            localStorage.removeItem("user_name");
            window.location.href = "index.php";
        });
    }

    function viewCart() {
        if (localStorage.getItem("user_id") === null) {
            window.location.href = "login.php";
            return;
        }
        window.location.href = "cart.php";
    }

    function goToProfile() {
        if (localStorage.getItem("user_id") === null) {
            window.location.href = "login.php";
            return;
        }
        window.location.href = "profile.php";
    }

    function showSearch() {
        window.location.href = "products.php"
    }

    // Load featured products from API
    async function loadFeaturedProducts() {
        try {
            const response = await fetch("api_products.php");
            const data = await response.json();

            if (data.products) {
                const container = document.querySelector(
                    ".grid.grid-cols-1.sm\\:grid-cols-2.md\\:grid-cols-4.gap-4.sm\\:gap-6",
                );

                container.innerHTML = data.products
                    .slice(0, 8)
                    .map(
                        (product) => `
            <div class="bg-white border-2 border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition cursor-pointer" onclick="viewProduct(${product.id})">
              <div class="bg-gray-100 h-40 flex items-center justify-center text-5xl overflow-hidden">
                ${product.image ? `<img src="${product.image}" alt="${product.name}" class="w-full h-full object-cover">` : getProductIcon(product.category)}
              </div>
              <div class="p-4">
                <p class="text-xs text-green-600 font-semibold">${product.category}</p>
                <h3 class="font-semibold text-gray-900 truncate">${product.name}</h3>
                <div class="flex justify-between items-center mt-3">
                  <span class="text-green-600 font-bold">₹${product.price}</span>
                  <button onclick="addToCart(event, ${product.id})" class="bg-green-500 text-white px-2 py-1 rounded text-xs hover:bg-green-600">Add</button>
                </div>
              </div>
            </div>
          `,
                    )
                    .join("");
            }
        } catch (error) {
            console.error("Error loading products:", error);
        }
    }

    function getProductIcon(category) {
        const icons = {
            Fruits: "🍎",
            Vegetables: "🥦",
            Dairy: "🧈",
            Bakery: "🍞",
            Beverages: "🥤",
            Snacks: "🍪",
        };
        return icons[category] || "📦";
    }

    function viewProduct(id) {
        window.location.href = `product.html?id=${id}`;
    }
async function addToCart(productId) {
    fetch("add_to_cart.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ product_id: productId })
    })
    .then(res => res.json())
    .then(data => {
        if (!data.success) {
            window.location.href = "login.php";
            return;
        }

        if (data.type === "added") {
            alert("✅ Product added to cart");
        } else if (data.type === "aldready_added") {
            alert("🛒 This Product Is Aldready Added To The Cart");
        }

        updateCartCount();
    });
}



    // Initialize on load
    updateAuthUI();
    loadFeaturedProducts();
    setInterval(updateCartCount, 5000); // Refresh cart count every 5 seconds
</script>

</html>