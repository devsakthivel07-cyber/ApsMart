<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database configuration for MySQL
define('DB_HOST', 'sql101.ezyro.com');
define('DB_USER', 'ezyro_41007419');
define('DB_PASS', 'a8bc9cfde');
define('DB_NAME', 'ezyro_41007419_apsmart');

// Start session for auth (only if not already started)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// PDO connection for all APIs
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    if (php_sapi_name() === 'cli') {
        die('DB connection failed: ' . $e->getMessage());
    }
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}
?>
