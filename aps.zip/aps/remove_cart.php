<?php
session_start();
require_once "config.php";
header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
  echo json_encode(["success"=>false]);
  exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$cart_id = $data['cart_id'] ?? null;

if (!$cart_id) {
  echo json_encode(["success"=>false]);
  exit;
}

$pdo->prepare("DELETE FROM cart WHERE id=?")->execute([$cart_id]);

echo json_encode(["success"=>true]);
