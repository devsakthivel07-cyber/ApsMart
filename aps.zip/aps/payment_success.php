<?php
session_start();
require_once "config.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($_SESSION['pending_order_id'])) {
    http_response_code(400);
    exit;
}

$orderId = $_SESSION['pending_order_id'];

$payment_id = $data['razorpay_payment_id'] ?? null;

if (!$payment_id) {
    http_response_code(400);
    exit;
}

/* Update order */
$pdo->prepare("
    UPDATE orders 
    SET status='paid', payment_id=?
    WHERE id=?
")->execute([$payment_id, $orderId]);

/* Clear cart */
$pdo->prepare("DELETE FROM cart WHERE user_id=?")
    ->execute([$_SESSION['user_id']]);

unset($_SESSION['pending_order_id']);

echo json_encode(["success"=>true]);
