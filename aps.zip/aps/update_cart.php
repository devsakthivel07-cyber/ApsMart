<?php
session_start();
require_once "config.php";

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$cart_id = $data['cart_id'] ?? null;
$action  = $data['action'] ?? null;

if (!$cart_id || !$action) {
    echo json_encode(["success" => false]);
    exit;
}

if ($action === "inc") {
    $pdo->prepare("UPDATE cart SET quantity = quantity + 1 WHERE id=?")
        ->execute([$cart_id]);
}

if ($action === "dec") {
    $pdo->prepare("
        UPDATE cart 
        SET quantity = IF(quantity>1, quantity-1, 1) 
        WHERE id=?
    ")->execute([$cart_id]);
}

/* fetch updated quantity + subtotal */
$stmt = $pdo->prepare("
    SELECT c.quantity, p.price 
    FROM cart c 
    JOIN products p ON p.id=c.product_id 
    WHERE c.id=?
");
$stmt->execute([$cart_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode([
    "success" => true,
    "quantity" => $row['quantity'],
    "subtotal" => $row['quantity'] * $row['price']
]);
?>