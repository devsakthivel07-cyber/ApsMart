<?php
require_once "config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ---------- HANDLE LOGIN (AJAX) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header("Content-Type: application/json");

    $data = json_decode(file_get_contents("php://input"), true);

    $email    = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';

    if ($email === '' || $password === '') {
        echo json_encode([
            "success" => false,
            "message" => "Email and password required"
        ]);
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode([
            "success" => false,
            "message" => "Invalid email"
        ]);
        exit;
    }

    $stmt = $pdo->prepare(
        "SELECT id, name, email, password 
         FROM users 
         WHERE email = ? 
         LIMIT 1"
    );
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        echo json_encode([
            "success" => false,
            "message" => "Invalid email or password"
        ]);
        exit;
    }

    // Store session
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_name']  = $user['name'];
    $_SESSION['user_email'] = $user['email'];

    echo json_encode([
        "success" => true,
        "user" => [
            "id"    => $user['id'],
            "name"  => $user['name'],
            "email" => $user['email']
        ],
        "redirect" => "index.php"
    ]);
    exit;
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - APS Mart</title>
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body class="bg-gray-50">
<main class="min-h-screen flex items-center justify-center px-4 py-12">
  <div class="w-full max-w-md">
    <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-8">
      <h2 class="text-3xl font-bold text-gray-900 mb-2 text-center">
        Welcome Back
      </h2>
      <p class="text-gray-600 text-center mb-8 text-sm">
        Sign in to continue shopping
      </p>

      <form id="loginForm" class="space-y-5">
        <div>
          <label class="block text-gray-800 font-semibold mb-2 text-sm">
            Email
          </label>
          <input
            type="email"
            id="email"
            class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-green-500"
            required
          />
        </div>

        <div>
          <label class="block text-gray-800 font-semibold mb-2 text-sm">
            Password
          </label>
          <input
            type="password"
            id="password"
            class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-green-500"
            required
          />
        </div>

        <button
          type="submit"
          class="w-full bg-green-500 text-white py-3 rounded-lg font-semibold hover:bg-green-600">
          Sign In
        </button>
      </form>

      <div class="flex items-center gap-3 my-6">
        <div class="flex-1 h-px bg-gray-300"></div>
        <span class="text-gray-500 text-xs font-semibold">OR</span>
        <div class="flex-1 h-px bg-gray-300"></div>
      </div>

      <!-- Google UI only -->
      <button
        class="w-full border border-gray-300 py-3 rounded-lg font-semibold text-gray-600">
        Continue with Google
      </button>

      <p class="text-center text-gray-600 mt-6 text-sm">
        Don't have an account?
        <a href="register.php" class="text-green-500 font-semibold">
          Sign Up
        </a>
      </p>
    </div>
  </div>
</main>

<script>
document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();

  fetch("login.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: document.getElementById("email").value,
      password: document.getElementById("password").value
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      localStorage.setItem("user_id", data.user.id);
      localStorage.setItem("user_name", data.user.name);
      localStorage.setItem("user_email", data.user.email);
      window.location.href = data.redirect;
    } else {
      alert(data.message);
    }
  })
  .catch(() => alert("Server error"));
});
</script>

</body>
</html>
