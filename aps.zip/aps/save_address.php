<?php
session_start();
require_once "config.php";

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT id FROM addresses WHERE user_id=?");
$stmt->execute([$user_id]);

if ($stmt->fetch()) {
    $upd = $pdo->prepare("UPDATE addresses SET address=?, city=?, pincode=? WHERE user_id=?");
    $upd->execute([$_POST['address'], $_POST['city'], $_POST['pincode'], $user_id]);
} else {
    $ins = $pdo->prepare("INSERT INTO addresses (user_id,address,city,pincode) VALUES (?,?,?,?)");
    $ins->execute([$user_id,$_POST['address'],$_POST['city'],$_POST['pincode']]);
}

header("Location: profile.php");
?>